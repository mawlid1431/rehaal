import React, { createContext, useContext, useState, useEffect } from 'react';

// Dark Mode Context
interface DarkModeContextType {
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

const DarkModeContext = createContext<DarkModeContextType | undefined>(undefined);

export const DarkModeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    const savedMode = localStorage.getItem('darkMode');
    if (savedMode) {
      setIsDarkMode(savedMode === 'true');
    }
  }, []);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('darkMode', String(isDarkMode));
  }, [isDarkMode]);

  const toggleDarkMode = () => setIsDarkMode(!isDarkMode);

  return (
    <DarkModeContext.Provider value={{ isDarkMode, toggleDarkMode }}>
      {children}
    </DarkModeContext.Provider>
  );
};

export const useDarkMode = () => {
  const context = useContext(DarkModeContext);
  if (context === undefined) {
    throw new Error('useDarkMode must be used within a DarkModeProvider');
  }
  return context;
};

// Language Context
export type Language = 'en' | 'da' | 'ar';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const translations = {
  en: {
    home: 'Home',
    about: 'About',
    trips: 'Trips',
    gallery: 'Gallery',
    testimonials: 'Testimonials',
    contact: 'Get in Touch',
    heroTitle: 'Your Spiritual Journey Starts Here',
    heroSubtitle: 'Experience Umrah with Rehaal Rejser - Denmark\'s trusted Muslim travel agency with over 500 satisfied pilgrims',
    bookJourney: 'Book Your Journey',
    viewMore: 'View More',
    aboutPreviewTitle: 'Welcome to Rehaal Rejser',
    tripsPreviewTitle: 'Upcoming Umrah Packages',
    testimonialsPreviewTitle: 'What Our Pilgrims Say',
    faq: 'FAQ',
    terms: 'Terms & Conditions',
    privacy: 'Privacy Policy',
    companyInfo: 'Company Info',
    quickLinks: 'Quick Links',
    legal: 'Legal',
    followUs: 'Follow Us',
    allRightsReserved: '© 2025 Rehaal Rejser. All rights reserved.',
    name: 'Name',
    email: 'Email',
    phone: 'Phone',
    message: 'Message',
    submit: 'Submit',
    destination: 'Destination',
    price: 'Price',
    viewDetails: 'View Details',
    backToTrips: 'Back to Trips',
  },
  da: {
    home: 'Hjem',
    about: 'Om Os',
    trips: 'Rejser',
    gallery: 'Galleri',
    testimonials: 'Anmeldelser',
    contact: 'Kontakt Os',
    heroTitle: 'Din Åndelige Rejse Begynder Her',
    heroSubtitle: 'Oplev Umrah med Rehaal Rejser - Danmarks betroede muslimske rejsebureau med over 500 tilfredse pilgrimme',
    bookJourney: 'Book Din Rejse',
    viewMore: 'Se Mere',
    aboutPreviewTitle: 'Velkommen til Rehaal Rejser',
    tripsPreviewTitle: 'Kommende Umrah Pakker',
    testimonialsPreviewTitle: 'Hvad Vores Pilgrimme Siger',
    faq: 'FAQ',
    terms: 'Vilkår & Betingelser',
    privacy: 'Privatlivspolitik',
    companyInfo: 'Virksomhedsinfo',
    quickLinks: 'Hurtige Links',
    legal: 'Juridisk',
    followUs: 'Følg Os',
    allRightsReserved: '© 2025 Rehaal Rejser. Alle rettigheder forbeholdes.',
    name: 'Navn',
    email: 'E-mail',
    phone: 'Telefon',
    message: 'Besked',
    submit: 'Send',
    destination: 'Destination',
    price: 'Pris',
    viewDetails: 'Se Detaljer',
    backToTrips: 'Tilbage til Rejser',
  },
  ar: {
    home: 'الرئيسية',
    about: 'من نحن',
    trips: 'الرحلات',
    gallery: 'المعرض',
    testimonials: 'الشهادات',
    contact: 'اتصل بنا',
    heroTitle: 'رحلتك الروحية تبدأ هنا',
    heroSubtitle: 'اختبر العمرة مع رحال ريسر - وكالة السفر الإسلامية الموثوقة في الدنمارك مع أكثر من 500 حاج راضٍ',
    bookJourney: 'احجز رحلتك',
    viewMore: 'عرض المزيد',
    aboutPreviewTitle: 'مرحبا بكم في رحال ريسر',
    tripsPreviewTitle: 'باقات العمرة القادمة',
    testimonialsPreviewTitle: 'ماذا يقول حجاجنا',
    faq: 'الأسئلة الشائعة',
    terms: 'الشروط والأحكام',
    privacy: 'سياسة الخصوصية',
    companyInfo: 'معلومات الشركة',
    quickLinks: 'روابط سريعة',
    legal: 'قانوني',
    followUs: 'تابعنا',
    allRightsReserved: '© 2025 رحال ريسر. جميع الحقوق محفوظة.',
    name: 'الاسم',
    email: 'البريد الإلكتروني',
    phone: 'الهاتف',
    message: 'الرسالة',
    submit: 'إرسال',
    destination: 'الوجهة',
    price: 'السعر',
    viewDetails: 'عرض التفاصيل',
    backToTrips: 'العودة إلى الرحلات',
  },
};

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  useEffect(() => {
    const savedLang = localStorage.getItem('language') as Language;
    if (savedLang && ['en', 'da', 'ar'].includes(savedLang)) {
      setLanguage(savedLang);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('language', language);
    if (language === 'ar') {
      document.documentElement.dir = 'rtl';
    } else {
      document.documentElement.dir = 'ltr';
    }
  }, [language]);

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations.en] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
