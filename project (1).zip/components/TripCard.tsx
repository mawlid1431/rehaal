import React from 'react';
import { motion } from 'motion/react';
import { Calendar, MapPin, DollarSign } from 'lucide-react';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface TripCardProps {
  trip: {
    id: number;
    title: string;
    destination: string;
    dates: string;
    price: string;
    image: string;
  };
  onViewDetails: (id: number) => void;
}

export const TripCard: React.FC<TripCardProps> = ({ trip, onViewDetails }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -8 }}
      transition={{ duration: 0.3 }}
      className="bg-card rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-shadow cursor-pointer"
      onClick={() => onViewDetails(trip.id)}
    >
      <div className="relative h-56 overflow-hidden">
        <motion.div
          whileHover={{ scale: 1.1 }}
          transition={{ duration: 0.4 }}
          className="w-full h-full"
        >
          <ImageWithFallback
            src={trip.image}
            alt={trip.title}
            className="w-full h-full object-cover"
          />
        </motion.div>
        <div className="absolute top-4 right-4 bg-[rgb(216,167,40)] text-white px-4 py-2 rounded-full">
          {trip.price}
        </div>
      </div>

      <div className="p-6">
        <h3 className="mb-3">{trip.title}</h3>
        
        <div className="space-y-2 mb-4">
          <div className="flex items-center text-muted-foreground">
            <MapPin className="w-4 h-4 mr-2" />
            <span className="text-sm">{trip.destination}</span>
          </div>
          <div className="flex items-center text-muted-foreground">
            <Calendar className="w-4 h-4 mr-2" />
            <span className="text-sm">{trip.dates}</span>
          </div>
        </div>

        <Button
          className="w-full"
          style={{ backgroundColor: 'rgb(216, 167, 40)' }}
          onClick={(e) => {
            e.stopPropagation();
            onViewDetails(trip.id);
          }}
        >
          View Details
        </Button>
      </div>
    </motion.div>
  );
};
