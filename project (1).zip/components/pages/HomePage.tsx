import React from 'react';
import { motion } from 'motion/react';
import { HeroSection } from '../HeroSection';
import { TripCard } from '../TripCard';
import { TestimonialCard } from '../TestimonialCard';
import { Button } from '../ui/button';
import { useLanguage } from '../../lib/contexts';
import { aboutCards, trips, testimonials } from '../../lib/data';

interface HomePageProps {
  onNavigate: (page: string, id?: number) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const { t } = useLanguage();

  const scrollToTrips = () => {
    const element = document.getElementById('trips-section');
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div>
      {/* Hero Section */}
      <HeroSection onBookJourney={scrollToTrips} />

      {/* About Rehaal Rejser Section */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl mb-4">Velkommen til Rehaal Rejser</h2>
            <div className="w-24 h-1 bg-[rgb(216,167,40)] mx-auto mb-6" />
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Vi er et dansk muslimsk rejsebureau specialiseret i at organisere Umrah og Hajj pilgrimsrejser til Saudi-Arabien. 
              Vores mål er at gøre disse åndelige rejser nemme, lærerige og mindeværdige for muslimer i Danmark.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {aboutCards.map((card, index) => (
              <motion.div
                key={card.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -5 }}
                className="bg-card p-6 rounded-xl shadow-lg text-center border border-border"
              >
                <div className="text-4xl mb-3">{card.icon}</div>
                <h3 className="mb-2">{card.title}</h3>
                <p className="text-muted-foreground text-sm">{card.description}</p>
              </motion.div>
            ))}
          </div>

          <div className="text-center">
            <Button
              variant="outline"
              onClick={() => onNavigate('about')}
              className="border-[rgb(216,167,40)] text-[rgb(216,167,40)] hover:bg-[rgb(216,167,40)] hover:text-white"
            >
              {t('viewMore')}
            </Button>
          </div>
        </div>
      </section>

      {/* Complete Services Section */}
      <section className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl mb-4">Komplet Umrah Rejsepakke</h2>
            <div className="w-24 h-1 bg-[rgb(216,167,40)] mx-auto mb-6" />
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Vi håndterer alt for dig, så du kan fokusere på din åndelige rejse uden at bekymre dig om logistik
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: '✈️', title: 'Flyvninger', desc: 'Direkte fly Danmark ↔ Saudi-Arabien' },
              { icon: '🏨', title: 'Luksushoteller', desc: 'Tæt på Haram i Makkah og Madinah' },
              { icon: '🛂', title: 'Visumbehandling', desc: 'Vi ordner alle visum-formalia' },
              { icon: '🚌', title: 'Transport', desc: 'Lokal transport under hele rejsen' },
              { icon: '🕌', title: 'Guidede Ture', desc: 'Besøg historiske og religiøse steder' },
              { icon: '📚', title: 'Seerah Ture', desc: 'Lærerige ture med korte islamiske talks' },
              { icon: '🎓', title: 'Umrah Seminar', desc: 'Forberedelsesseminar før afrejse' },
              { icon: '🤝', title: 'Fuld Support', desc: 'Dansk-talende ledere med erfaring' },
            ].map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                className="bg-card p-6 rounded-lg shadow-md text-center border border-border"
              >
                <div className="text-4xl mb-3">{service.icon}</div>
                <h4 className="mb-2">{service.title}</h4>
                <p className="text-sm text-muted-foreground">{service.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Trips Preview Section */}
      <section id="trips-section" className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl mb-4">{t('tripsPreviewTitle')}</h2>
            <div className="w-24 h-1 bg-[rgb(216,167,40)] mx-auto" />
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-8">
            {trips.slice(0, 3).map((trip) => (
              <TripCard
                key={trip.id}
                trip={trip}
                onViewDetails={(id) => onNavigate('trip-detail', id)}
              />
            ))}
          </div>

          <div className="text-center">
            <Button
              variant="outline"
              onClick={() => onNavigate('trips')}
              className="border-[rgb(216,167,40)] text-[rgb(216,167,40)] hover:bg-[rgb(216,167,40)] hover:text-white"
            >
              {t('viewMore')}
            </Button>
          </div>
        </div>
      </section>

      {/* Why Rehaal Rejser - Statistics Section */}
      <section className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl mb-4">Hvorfor Vælge Rehaal Rejser?</h2>
            <div className="w-24 h-1 bg-[rgb(216,167,40)] mx-auto mb-6" />
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-card p-8 rounded-xl shadow-lg border border-border"
            >
              <h3 className="text-2xl mb-4 text-[rgb(216,167,40)]">Vores Mission</h3>
              <p className="text-muted-foreground leading-relaxed">
                At gøre Umrah og Hajj rejser <strong>nemme, lærerige og mindeværdige</strong> for muslimer i Danmark 
                og nærliggende regioner. Vi opererer i overensstemmelse med islamiske principper og sikrer halal-praksis 
                gennem hele rejsen.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-card p-8 rounded-xl shadow-lg border border-border"
            >
              <h3 className="text-2xl mb-4 text-[rgb(216,167,40)]">Vores Løfte</h3>
              <p className="text-muted-foreground leading-relaxed">
                Vi tilbyder <strong>islamisk uddannelse og åndelig støtte</strong> gennem hele rejsen. 
                Vores dansk-talende ledere fungerer både som åndelige mentorer og praktiske koordinatorer, 
                hvilket skaber et støttende, tro-drevet fællesskab.
              </p>
            </motion.div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { number: '500+', label: 'Tilfredse Pilgrimme', icon: '👥' },
              { number: '15+', label: 'Års Erfaring', icon: '⭐' },
              { number: '100%', label: 'Halal Garanti', icon: '✅' },
              { number: '24/7', label: 'Support Under Rejsen', icon: '🤝' },
            ].map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-card p-6 rounded-xl shadow-md text-center border border-border"
              >
                <div className="text-3xl mb-2">{stat.icon}</div>
                <div className="text-3xl mb-2" style={{ color: 'rgb(216, 167, 40)' }}>
                  {stat.number}
                </div>
                <p className="text-muted-foreground">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Preview Section */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl mb-4">{t('testimonialsPreviewTitle')}</h2>
            <div className="w-24 h-1 bg-[rgb(216,167,40)] mx-auto" />
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            {testimonials.slice(0, 3).map((testimonial, index) => (
              <TestimonialCard
                key={testimonial.id}
                testimonial={testimonial}
                delay={index * 0.1}
              />
            ))}
          </div>

          <div className="text-center">
            <Button
              variant="outline"
              onClick={() => onNavigate('testimonials')}
              className="border-[rgb(216,167,40)] text-[rgb(216,167,40)] hover:bg-[rgb(216,167,40)] hover:text-white"
            >
              {t('viewMore')}
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};
