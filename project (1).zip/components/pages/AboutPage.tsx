import React from 'react';
import { motion } from 'motion/react';
import { Heart, Award, Users, Globe } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export const AboutPage: React.FC = () => {
  const values = [
    {
      icon: <Heart className="w-8 h-8" />,
      title: 'Compassionate Service',
      description: 'We treat every pilgrim with care and respect, understanding the sacred nature of their journey.'
    },
    {
      icon: <Award className="w-8 h-8" />,
      title: 'Excellence',
      description: '15+ years of experience delivering exceptional Umrah and Hajj packages with attention to detail.'
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: 'Community',
      description: 'Building lasting relationships with our travelers and creating a supportive community.'
    },
    {
      icon: <Globe className="w-8 h-8" />,
      title: 'Global Expertise',
      description: 'International partnerships ensuring smooth travel experiences across continents.'
    }
  ];

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative h-96 flex items-center justify-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: 'url(https://images.unsplash.com/photo-1632782532013-bd3f5f9197db?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpc2xhbWljJTIwYXJjaGl0ZWN0dXJlfGVufDF8fHx8MTc2MTIyMzEzOHww&ixlib=rb-4.1.0&q=80&w=1080)'
          }}
        />
        <div className="absolute inset-0 bg-black/60" />
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative text-center text-white z-10"
        >
          <h1 className="text-4xl md:text-5xl mb-4 text-white">About Rehaal Travel</h1>
          <div className="w-24 h-1 bg-[rgb(216,167,40)] mx-auto" />
        </motion.div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-3xl mb-6">Our Story</h2>
              <p className="text-muted-foreground mb-4">
                Founded in 2008, Rehaal Travel was born from a simple vision: to make the sacred journey of Umrah accessible, comfortable, and spiritually enriching for Muslims across Europe.
              </p>
              <p className="text-muted-foreground mb-4">
                What started as a small family business has grown into one of Denmark's most trusted Umrah and Hajj travel specialists. We've had the honor of facilitating thousands of spiritual journeys, each one treated with the utmost care and dedication.
              </p>
              <p className="text-muted-foreground">
                Our team combines deep religious knowledge with modern travel expertise, ensuring that every aspect of your journey—from visa processing to accommodation—is handled with professionalism and Islamic values at heart.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative h-96 rounded-xl overflow-hidden shadow-2xl"
            >
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1733895422344-672960e0de80?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWRpbmFoJTIwbW9zcXVlJTIwaXNsYW1pY3xlbnwxfHx8fDE3NjEyNDAzMTB8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Madinah"
                className="w-full h-full object-cover"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl mb-4">Our Values</h2>
            <div className="w-24 h-1 bg-[rgb(216,167,40)] mx-auto" />
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -5 }}
                className="bg-card p-6 rounded-xl shadow-lg text-center"
              >
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[rgb(216,167,40)]/10 text-[rgb(216,167,40)] mb-4">
                  {value.icon}
                </div>
                <h3 className="mb-3">{value.title}</h3>
                <p className="text-muted-foreground text-sm">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl mb-4">Why Choose Rehaal Travel?</h2>
            <div className="w-24 h-1 bg-[rgb(216,167,40)] mx-auto" />
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: 'Experienced Team',
                description: 'Our team has over 15 years of experience organizing Umrah and Hajj journeys, ensuring every detail is perfect.'
              },
              {
                title: 'Premium Accommodations',
                description: 'Stay in comfort with carefully selected hotels close to the holy sites, providing convenience and peace of mind.'
              },
              {
                title: 'Spiritual Guidance',
                description: 'Travel with knowledgeable guides who provide religious insights and support throughout your sacred journey.'
              },
              {
                title: 'Competitive Pricing',
                description: 'We offer transparent, fair pricing with no hidden costs, ensuring exceptional value for your investment.'
              },
              {
                title: '24/7 Support',
                description: 'Round-the-clock assistance during your journey, so you can focus on your spiritual experience with peace of mind.'
              },
              {
                title: 'Complete Packages',
                description: 'All-inclusive packages covering flights, accommodations, visas, transportation, and guided tours.'
              }
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-card p-6 rounded-xl border border-border"
              >
                <h4 className="mb-3 text-[rgb(216,167,40)]">{item.title}</h4>
                <p className="text-muted-foreground text-sm">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};
