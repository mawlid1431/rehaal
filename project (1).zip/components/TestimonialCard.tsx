import React from 'react';
import { motion } from 'motion/react';
import { Star } from 'lucide-react';

interface TestimonialCardProps {
  testimonial: {
    id: number;
    name: string;
    rating: number;
    comment: string;
    date: string;
    trip: string;
  };
  delay?: number;
}

export const TestimonialCard: React.FC<TestimonialCardProps> = ({ testimonial, delay = 0 }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ y: -5 }}
      className="bg-card p-6 rounded-xl shadow-lg border border-border"
    >
      <div className="flex items-center mb-4">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            className={`w-5 h-5 ${
              i < testimonial.rating
                ? 'fill-[rgb(216,167,40)] text-[rgb(216,167,40)]'
                : 'text-gray-300'
            }`}
          />
        ))}
      </div>

      <p className="text-muted-foreground mb-4 italic">"{testimonial.comment}"</p>

      <div className="border-t border-border pt-4">
        <p className="text-sm">{testimonial.name}</p>
        <p className="text-sm text-muted-foreground">{testimonial.trip}</p>
        <p className="text-xs text-muted-foreground mt-1">{testimonial.date}</p>
      </div>
    </motion.div>
  );
};
